import UIKit

var num = 1

while num <= 5 {
    num += 1
    print("and they all go marching down to the ground, to get out of the rain")
}
if num == 1 {
    print("The ants go marching one by one- hurrah, hurrah ")
} else {
    print("the little one stops to suck his thumb")
}

